'use client'

import { useParams } from 'next/navigation'

const courses = {
  1: { title: 'Introduction to React', videoUrl: '/placeholder.mp4' },
  2: { title: 'Advanced JavaScript', videoUrl: '/placeholder.mp4' },
  3: { title: 'Web Design Fundamentals', videoUrl: '/placeholder.mp4' },
}

export default function Course() {
  const params = useParams()
  const courseId = params.id as string
  const course = courses[courseId as keyof typeof courses]

  if (!course) {
    return <div>Course not found</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">{course.title}</h1>
      <div className="aspect-w-16 aspect-h-9">
        <video controls className="w-full">
          <source src={course.videoUrl} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
    </div>
  )
}

